# Read the data
data = read.csv("data_purchase_behaviour.csv")
# View the structure of the dataset
str(data)
# Summary statistics for numerical variables
summary(data)
# Frequency tables for categorical variables
table(data$Gender)
table(data$City.Category)
table(data$Stay.In.Current.City.Years)
table(data$Marital.Status)
# Visualizations
library(ggplot2)

# Histogram for Purchase
ggplot(data, aes(x = Purchase)) +
  geom_histogram(binwidth = 1000, fill = "blue", alpha = 0.7) +
  labs(title = "Distribution of Purchase Amount", x = "Purchase Amount", y = "Frequency")

# Histogram for Age
ggplot(data, aes(x = Age_num)) +
  geom_histogram(binwidth = 5, fill = "green", alpha = 0.7) +
  labs(title = "Distribution of Age", x = "Age", y = "Frequency")

# Bar plot for Gender
ggplot(data, aes(x = Gender)) +
  geom_bar(fill = "orange", alpha = 0.7) +
  labs(title = "Gender Distribution", x = "Gender", y = "Count")
# Additional descriptive statistics
# Calculating standard deviation for numerical variables
sd_age <- sd(data$Age.num)
sd_purchase <- sd(data$Purchase)
# Display results
cat("Standard Deviation of Age:", sd_age, "\n")
cat("Standard Deviation of Purchase:", sd_purchase, "\n")
# Analysis of gender and marital status
cat("Gender Distribution:\n")
print(table(data$Gender))

cat("Marital Status Distribution:\n")
print(table(data$Marital.Status))

cat("City Category Distribution:\n")
print(table(data$City.Category))

cat("Stay in Current City Years:\n")
print(table(data$Stay.In.Current.City.Years))

# Q2 Use a Simple Linear Regression Model to Investigate Purchase Amount
# and Age
# a) Fit the Model by Estimating Intercept, Slope, and Uncertainties
# Define variables
age <- data$Age_num         # Predictor variable (Age)
purchase <- data$Purchase   # Response variable (Purchase amount)

# Calculate means of age and purchase
mean_age <- mean(age)
mean_purchase <- mean(purchase)

# Calculate slope (b1) and intercept (b0)
numerator <- sum((age - mean_age) * (purchase - mean_purchase))
denominator <- sum((age - mean_age)^2)
b1 <- numerator / denominator  # Slope
b0 <- mean_purchase - b1 * mean_age  # Intercept
# Calculate residuals
residuals <- purchase - (b0 + b1 * age)
# Estimate variance of residuals
n <- length(age)
sample_variance <- sum(residuals^2) / (n - 2)
# Standard errors of slope and intercept
se_b1 <- sqrt(sample_variance / denominator)
se_b0 <- sqrt(sample_variance * (1/n + (mean_age^2) / denominator))

# Display results
cat("Intercept (b0):", b0, "\n")
cat("Slope (b1):", b1, "\n")
cat("Standard Error of Intercept:", se_b0, "\n")
cat("Standard Error of Slope:", se_b1, "\n")

#Additional Explanation using Visualizations
# Purchase Distribution
library(ggplot2)
ggplot(data, aes(x = Purchase)) + 
  geom_histogram(bins = 30, fill = "skyblue", color = "black") +
  labs(title = "Distribution of Purchase Amount", x = "Purchase Amount", y = "Frequency")

# Purchase by Gender
ggplot(data, aes(x = Gender, y = Purchase)) +
  geom_boxplot(fill = "skyblue") +
  labs(title = "Purchase Amount by Gender", x = "Gender", y = "Purchase Amount")
# Regression Plot
ggplot(data, aes(x = Age_num, y = Purchase)) +
  geom_point(alpha = 0.1) +
  geom_abline(intercept = b0, slope = b1, color = "red", size = 1) +
  labs(title = "Purchase Amount vs Age with Regression Line", x = "Age", y = "Purchase Amount")
# 3. Investigate the Association Between Purchase Amount and Gender
#Gender Analysis
# Summary Statistics by Gender
cat("\nPurchase Amount Summary by Gender:\n")
gender_summary <- aggregate(Purchase ~ Gender, data = data, FUN = function(x) c(
  mean = mean(x),
  sd = sd(x),
  n = length(x)
))
print(gender_summary)

# t-test
t_test <- t.test(Purchase ~ Gender, data = data)
cat("\nT-Test Results:\n")
print(t_test)

# Effect Size (Cohen's d)
mean_diff <- abs(diff(t_test$estimate))
pooled_sd <- sqrt(((t_test$parameter * var(data[data$Gender == "M", "Purchase"])) +
                     ((length(data[data$Gender == "F", "Purchase"]) - 1) * var(data[data$Gender == "F", "Purchase"]))) /
                    (t_test$parameter + 1))
cohens_d <- mean_diff / pooled_sd
cat("Cohen's d (Effect Size):", cohens_d, "\n")

# Gender Boxplot
ggplot(data, aes(x = Gender, y = Purchase)) +
  geom_boxplot(fill = "steelblue") +
  labs(title = "Purchase Amount by Gender", x = "Gender", y = "Purchase Amount") +
  theme_minimal()
