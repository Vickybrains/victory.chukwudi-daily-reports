# Load the dataset
dataset <- read.csv("lending_dataset1_aggr.csv")

# View structure and summary
str(dataset)
summary(dataset)

# Check for missing values
colSums(is.na(dataset))
#data cleansing
library(Amelia)  
missmap(dataset, main = "Missing Values Map", col = c("yellow", "black"), legend = TRUE)
numeric_summary <- data.frame(
  Variable = names(numeric_vars),
  Min = sapply(numeric_vars, min, na.rm = TRUE),
  Max = sapply(numeric_vars, max, na.rm = TRUE),
  Mean = sapply(numeric_vars, mean, na.rm = TRUE),
  Median = sapply(numeric_vars, median, na.rm = TRUE),
  SD = sapply(numeric_vars, sd, na.rm = TRUE)
)
print(numeric_summary)
par(mfrow = c(2, 3))  # Adjust grid size
for (col in names(numeric_vars)) {
  boxplot(numeric_vars[[col]], 
          main = paste("Boxplot of", col), 
          col = "skyblue", 
          ylab = col, 
          horizontal = TRUE)
  abline(v = median(numeric_vars[[col]], na.rm = TRUE), col = "red", lty = 2)  # Add median line
}
par(mfrow = c(2, 3))  # Adjust grid size
for (col in names(numeric_vars)) {
  hist(numeric_vars[[col]], 
       main = paste("Histogram of", col), 
       xlab = col, 
       col = "lightgreen", 
       breaks = 15)
}
numeric_vars <- dataset[sapply(dataset, is.numeric)]
numeric_summary <- data.frame(
  Variable = names(numeric_vars),
  Min = sapply(numeric_vars, min, na.rm = TRUE),
  Max = sapply(numeric_vars, max, na.rm = TRUE),
  Mean = sapply(numeric_vars, mean, na.rm = TRUE),
  Median = sapply(numeric_vars, median, na.rm = TRUE),
  SD = sapply(numeric_vars, sd, na.rm = TRUE)
)
print(numeric_summary)
outliers <- lapply(numeric_vars, function(x) {
  Q1 <- quantile(x, 0.25, na.rm = TRUE)
  Q3 <- quantile(x, 0.75, na.rm = TRUE)
  IQR <- Q3 - Q1
  list(LowerBound = Q1 - 1.5 * IQR, UpperBound = Q3 + 1.5 * IQR,
       Outliers = x[x < (Q1 - 1.5 * IQR) | x > (Q3 + 1.5 * IQR)])
})

print(outliers)
# Visualizing distributions of key variables
# Load necessary libraries

library(ggplot2)
library(dplyr)
par(mfrow = c(2, 2))  # Arrange plots
hist(dataset$Age, main = "Age Distribution", xlab = "Age", col = "lightblue")
hist(dataset$Earnings, main = "Earnings Distribution", xlab = "Earnings (CFA)", col = "lightgreen")
hist(dataset$ObsRate, main = "Observed Default Rate", xlab = "ObsRate", col = "lightcoral")
barplot(table(dataset$BadPastRecords), main = "BadPastRecords Frequency", col = "gold")

# Bar plots for categorical variables
ggplot(dataset, aes(x = Gender)) + geom_bar(fill = "blue") + ggtitle("Distribution of Gender")
ggplot(dataset, aes(x = HomeOwner)) + geom_bar(fill = "green") + ggtitle("Distribution of Home Ownership")
# Density plots for numerical variables
numeric_vars <- dataset[sapply(dataset, is.numeric)]
par(mfrow = c(2, 3))  # Adjust the layout as needed
for (col in names(numeric_vars)) {
  plot(density(numeric_vars[[col]], na.rm = TRUE), main = paste("Density Plot of", col), col = "darkblue")
}

# Pairwise scatter plots for selected numerical variables
pairs(~ Earnings + Age + Experience + ObsRate, data = dataset, main = "Pairwise Scatter Plots")

# Frequency tables for categorical variables
cat_vars <- c("Gender", "Residence", "HomeOwner", "LandOwner", "CarOwner")
for (var in cat_vars) {
  cat("Frequency table for", var, ":\n")
  print(table(dataset[[var]]))
  cat("\n")
}
cat_vars <- c("Gender", "Residence", "HomeOwner", "LandOwner", "CarOwner")

for (var in cat_vars) {
  freq_table <- table(dataset[[var]])
  percent_table <- prop.table(freq_table) * 100
  print(data.frame(Count = freq_table, Percentage = percent_table))
}
# Correlation matrix for numerical variables
cor_matrix <- cor(dataset[, sapply(dataset, is.numeric)], use = "complete.obs")
print(cor_matrix)
library(ggcorrplot)
ggcorrplot(cor_matrix, lab = TRUE, colors = c("blue", "white", "red"))
# Fit a GLM model with binomial distribution
# Convert categorical variables to factors

categorical_vars <- c("Gender", "Residence", "HomeOwner", "LandOwner", "BadPastRecords", "CarOwner")
dataset[categorical_vars] <- lapply(dataset[categorical_vars], as.factor)
single_level_vars <- sapply(dataset[categorical_vars], function(x) length(unique(x)) == 1)
if (any(single_level_vars)) {
  print("Variables with single levels:")
  print(names(single_level_vars[single_level_vars]))
}
dataset <- dataset[, !names(dataset) %in% names(single_level_vars[single_level_vars])]

# Convert `Defaults` to binary
dataset$Defaults <- ifelse(dataset$Defaults > 0, 1, 0)
dataset$Defaults <- as.numeric(as.character(dataset$Defaults))
dataset$Accounts <- as.numeric(as.character(dataset$Accounts))

# Check for missing values and handle them
sum(is.na(dataset))  # Count total missing values
dataset <- na.omit(dataset)  # Remove rows with missing values

# `Defaults` is treated as a factor for logistic regression
dataset$Defaults <- as.factor(dataset$Defaults)

# Scale numerical variables (optional but improves model convergence)
dataset$Age <- scale(dataset$Age)
dataset$Experience <- scale(dataset$Experience)
dataset$Earnings <- scale(dataset$Earnings)

# Fit the logistic regression model
table(dataset$Defaults)
table(dataset$Defaults, dataset$Earnings > threshold)  # Replace 'threshold' with a value
boxplot(dataset[sapply(dataset, is.numeric)])
# Fit logistic regression with regularization (lasso)
x <- model.matrix(Defaults ~ Age + Gender + Experience + Earnings + Residence + HomeOwner + LandOwner + BadPastRecords + CarOwner, data = dataset_balanced)[, -1]
y <- dataset_balanced$Defaults
lasso_fit <- cv.glmnet(x, as.numeric(as.character(y)), family = "binomial", alpha = 1)


robust_model <- glm(Defaults ~ Age + Gender + Experience + Earnings + Residence + HomeOwner + LandOwner + BadPastRecords + CarOwner, 
                    data = dataset_balanced, 
                    family = binomial(link = "logit"), 
                    control = glm.control(maxit = 100, epsilon = 1e-8))

# Model summary
summary(robust_model)
# Predict probabilities
probabilities <- predict(lasso_fit, newx = x, s = "lambda.min", type = "response")
probabilities <- pmin(pmax(probabilities, 1e-5), 1 - 1e-5)

summary(dataset[sapply(dataset, is.numeric)])

# View the model summary
summary(model)


# Visualize the relationship
plot(dataset$Age, dataset$ObsRate, main = "ObsRate vs Age",
     xlab = "Age (scaled)", ylab = "ObsRate",
     col = "blue", pch = 16)
abline(lm_simple, col = "red", lwd = 2)


calculate_vif <- function(model) {
  # Extract design matrix (includes dummy variables for categorical predictors)
  design_matrix <- model.matrix(model)
  
  # Remove the intercept column (typically the first column)
  design_matrix <- design_matrix[, -1, drop = FALSE]
  
  # Initialize a vector to store VIF values
  vif_values <- numeric(ncol(design_matrix))
  names(vif_values) <- colnames(design_matrix)
  
  # Compute VIF for each predictor
  for (i in seq_along(vif_values)) {
    # Response is the current predictor
    response <- design_matrix[, i]
    
    # Predictors are all other columns
    predictors <- design_matrix[, -i, drop = FALSE]
    
    # Fit linear model
    sub_model <- lm(response ~ predictors)
    
    # Compute R-squared
    r_squared <- summary(sub_model)$r.squared
    
    # Compute VIF
    vif_values[i] <- 1 / (1 - r_squared)
  }
  
  return(vif_values)
}

# Apply the function to your GLM model
vif_values <- calculate_vif(glm_model)
vif_values
summary(glm_model)
# Convert coefficients to odds ratios
exp(coef(model))
table(dataset$ObsRate)  # Check class balance
summary(dataset)  # Examine predictor distributions
# Residual diagnostics for GLM
plot(residuals(model, type = "deviance") ~ fitted(model), 
     xlab = "Fitted Values", 
     ylab = "Deviance Residuals", 
     main = "Deviance Residuals vs Fitted Values")
abline(h = 0, col = "red")
# Get the model coefficients
exp_coef <- exp(cbind(Estimate = coef(model), confint(model)))
print(exp_coef)
# Fit models with different subsets of predictors
dataset$Defaults <- as.numeric(as.character(dataset$Defaults))
dataset$Accounts <- as.numeric(as.character(dataset$Accounts))

model_1 <- glm(cbind(Defaults, Accounts - Defaults) ~ Age + Gender + Experience + Earnings, 
               data = dataset, family = binomial(link = "logit"))

model_2 <- glm(cbind(Defaults, Accounts - Defaults) ~ Age + Earnings + HomeOwner, 
               data = dataset, family = binomial(link = "logit"))

# Compare models
cat("AIC for Model 1:", AIC(model_1), "\n")
cat("AIC for Model 2:", AIC(model_2), "\n")

# Select the model with the lowest AIC

best_model <- if (AIC(model_1) < AIC(model_2)) model_1 else model_2
summary(best_model)
library(ResourceSelection)
hoslem.test(dataset$Defaults, fitted(best_model))


# Load libraries
library(ggplot2)
library(glmnet)
library(ROSE)


# Data cleaning
dataset <- na.omit(dataset)  # Remove missing values
dataset[categorical_vars] <- lapply(dataset[categorical_vars], as.factor)  # Convert categorical vars to factors
dataset$Defaults <- as.factor(ifelse(dataset$Defaults > 0, 1, 0))  # Convert Defaults to binary

# Check for class imbalance
table(dataset$Defaults)
dataset_balanced <- ovun.sample(Defaults ~ ., data = dataset, method = "over", N = 2 * max(table(dataset$Defaults)))$data

# Scale numerical variables
numeric_vars <- dataset_balanced[sapply(dataset_balanced, is.numeric)]
dataset_balanced[sapply(dataset_balanced, is.numeric)] <- scale(numeric_vars)



